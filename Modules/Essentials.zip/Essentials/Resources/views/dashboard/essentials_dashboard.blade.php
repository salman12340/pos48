@extends('layouts.app')
@section('title', __('essentials::lang.holiday'))

@section('content')
@include('essentials::layouts.nav_essentials')
<!-- Main content -->
<section class="content">

</section>
<!-- /.content -->
@endsection
